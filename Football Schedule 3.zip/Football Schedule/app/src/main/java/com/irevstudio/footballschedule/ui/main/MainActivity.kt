/*
 * Created On : 10/25/18 10:03 PM
 * Author : Aqil Prakoso
 * Copyright (c) 2018 iRevStudio
 *
 */

package com.irevstudio.footballschedule.ui.main

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.app.AppCompatActivity
import com.irevstudio.footballschedule.R
import com.irevstudio.footballschedule.R.id.*
import com.irevstudio.footballschedule.ui.FavoritesFragment
import com.irevstudio.footballschedule.ui.MatchFragment
import com.irevstudio.footballschedule.ui.favorites.TeamFavoritesFragment
import com.irevstudio.footballschedule.ui.team.TeamFragment
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bottom_navigation.setOnNavigationItemSelectedListener { item ->

            var fragment: Fragment? = null
            when (item.itemId) {
                teams -> {
                   fragment = TeamFragment()
                }
                events -> {
                    fragment = MatchFragment()
                }
                favorites -> {
                    fragment = FavoritesFragment()
                }

            }
            loadFragment(fragment)
            return@setOnNavigationItemSelectedListener true
        }
        bottom_navigation.selectedItemId = events

    }

    private fun loadFragment(fragment: Fragment?){
        if (fragment != null){
            supportFragmentManager
                    .beginTransaction()
                    .replace(R.id.main_frameLayout, fragment)
                    .commit()
        }
    }

}

