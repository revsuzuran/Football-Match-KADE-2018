/*
 * Created On : 10/29/18 5:27 AM
 * Author : Aqil Prakoso
 * Copyright (c) 2018 iRevStudio
 *
 */

package com.irevstudio.footballschedule.ui.nextmatch

import android.graphics.Color
import android.os.Build
import android.support.annotation.RequiresApi
import android.support.v7.widget.RecyclerView
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.irevstudio.footballschedule.R
import com.irevstudio.footballschedule.model.Match
import org.jetbrains.anko.*
import org.jetbrains.anko.cardview.v7.cardView

class NextMatchAdapter(private val match: List<Match>)
    : RecyclerView.Adapter<NextMatchViewHolder>(){
    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NextMatchViewHolder {
        return NextMatchViewHolder(NextMatchUI().createView(AnkoContext.create(parent.context, parent)))
    }

    override fun getItemCount(): Int = match.size

    override fun onBindViewHolder(holder: NextMatchViewHolder, position: Int) {
        holder.bindItem(match[position])
    }

}

class NextMatchUI : AnkoComponent<ViewGroup> {
    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    override fun createView(ui: AnkoContext<ViewGroup>): View {
        return with(ui) {

            cardView {
                lparams(width = matchParent, height = wrapContent) { margin = dip(6) }
                radius = 4f
                elevation = 4f

                linearLayout {
                    padding = dip(10)
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER

                    textView {
                        id = R.id.nextMatch_homeName
                        textSize = 16f
                        textAlignment = LinearLayout.TEXT_ALIGNMENT_CENTER
                    }.lparams {
                        width = matchParent
                        height = wrapContent
                        weight = 0.5f
                    }

                    textView {
                        id = R.id.nextMatch_homeSkor
                        textSize = 16f
                    }

                    textView {
                        text = ctx.getString(R.string.versus)
                        textSize = 20f
                    }.lparams { margin = dip(10) }

                    textView {
                        id = R.id.nextMatch_awaySkor
                        textSize = 16f
                    }

                    textView {
                        id = R.id.nextMatch_awayName
                        textSize = 16f
                        textAlignment = LinearLayout.TEXT_ALIGNMENT_CENTER
                    }.lparams {
                        width = matchParent
                        height = wrapContent
                        weight = 0.5f
                    }

                }
            }
        }

    }
}

class NextMatchViewHolder(view: View): RecyclerView.ViewHolder(view){

    private val homeName: TextView = view.find(R.id.nextMatch_homeName)
    private val homeSkor: TextView = view.find(R.id.nextMatch_homeSkor)
    private val awayName: TextView = view.find(R.id.nextMatch_awayName)
    private val awaySkor: TextView = view.find(R.id.nextMatch_awaySkor)

    fun bindItem(match: Match){

        homeName.text = match.teamHome
        homeSkor.text = match.teamHomeScore.toString();if(homeSkor.text == "null"){homeSkor.text = "-"}
        awayName.text = match.teamAway
        awaySkor.text = match.teamAwayScore.toString();if(awaySkor.text == "null"){awaySkor.text = "-"}

    }
}