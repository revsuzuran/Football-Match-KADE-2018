package com.irevstudio.footballschedule.ui.teamdetail

import com.google.gson.Gson
import com.irevstudio.footballschedule.api.ApiRepository
import com.irevstudio.footballschedule.api.FootballDBApi
import com.irevstudio.footballschedule.model.TeamResponse
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread

class TeamDetailPresenter(private val view: TeamDetailView,
                          private val apiRepository: ApiRepository,
                          private val gson: Gson){

    fun getTeamDetail(teamId: String?){
        view.showLoading()
        doAsync {
            val data = gson.fromJson(apiRepository
                    .lakukanPermintaan(FootballDBApi.ambilDetailteam(teamId)),
            TeamResponse::class.java
            )

            uiThread {
                view.hideLoading()
                view.showTeamDetail(data.teams)
            }

        }
    }
}