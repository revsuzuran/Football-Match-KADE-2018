/*
 * Created On : 10/30/18 2:13 PM
 * Author : Aqil Prakoso
 * Copyright (c) 2018 iRevStudio
 *
 */

package com.irevstudio.footballschedule.ui.match


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.view.ViewPager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.irevstudio.footballschedule.R
import com.irevstudio.footballschedule.adapter.MatchTabAdapter


class MatchFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_match, container, false)

        val viewPager = view.findViewById<ViewPager>(R.id.viewPager)
       viewPager.adapter = MatchTabAdapter(activity?.supportFragmentManager)

        return view
    }


}
