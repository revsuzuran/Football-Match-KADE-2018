package com.irevstudio.footballschedule.ui.match

import android.os.Build
import android.support.annotation.RequiresApi
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import com.irevstudio.footballschedule.R
import org.jetbrains.anko.*
import org.jetbrains.anko.cardview.v7.cardView

class MatchUI : AnkoComponent<ViewGroup> {
    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    override fun createView(ui: AnkoContext<ViewGroup>): View {
        return with(ui) {

            cardView {
                lparams(width = matchParent, height = wrapContent) { margin = dip(6) }
                radius = 4f
                elevation = 4f

                linearLayout {
                    padding = dip(10)
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER

                    textView {
                        id = R.id.nextMatch_homeName
                        textSize = 16f
                        textAlignment = LinearLayout.TEXT_ALIGNMENT_CENTER
                    }.lparams {
                        width = matchParent
                        height = wrapContent
                        weight = 0.5f
                    }

                    textView {
                        id = R.id.nextMatch_homeSkor
                        textSize = 16f
                    }

                    textView {
                        text = ctx.getString(R.string.versus)
                        textSize = 20f
                    }.lparams { margin = dip(10) }

                    textView {
                        id = R.id.nextMatch_awaySkor
                        textSize = 16f
                    }

                    textView {
                        id = R.id.nextMatch_awayName
                        textSize = 16f
                        textAlignment = LinearLayout.TEXT_ALIGNMENT_CENTER
                    }.lparams {
                        width = matchParent
                        height = wrapContent
                        weight = 0.5f
                    }

                }
            }
        }

    }
}