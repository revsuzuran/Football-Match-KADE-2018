package com.irevstudio.footballschedule.model

data class LeagueResponse(
        val leagues: List<LeaguesItem>)