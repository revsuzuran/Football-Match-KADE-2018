package com.irevstudio.footballschedule.model

data class PlayerDetailResponse(
        val players: List<Player>
)