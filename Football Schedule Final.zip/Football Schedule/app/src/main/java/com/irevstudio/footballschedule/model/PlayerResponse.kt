package com.irevstudio.footballschedule.model

data class PlayerResponse(
	val player: List<Player>
)
