package com.irevstudio.footballschedule.model

data class SearchMatchResponse(
        val event: List<Match>)